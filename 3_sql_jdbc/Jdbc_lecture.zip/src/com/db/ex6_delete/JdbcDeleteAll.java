package com.db.ex6_delete;

import java.sql.*;

public class JdbcDeleteAll {
	
	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;
		int retval=0;
		String id= "apple";
		
		String driverName = "com.mysql.jdbc.Driver";
		String DBName = "jdbc_db";
		String dbURL = "jdbc:mysql://localhost:3306/" + DBName;
		String sslStr="?useSSL=false";

		String sql = "delete from user";
	

		try {
			Class.forName(driverName);
			pstmt = con.prepareStatement(sql);
			retval=pstmt.executeUpdate();
			System.out.println(retval);

			System.out.println("delete ����");
		}
		catch (ClassNotFoundException e) {
				System.out.println("JDBC driver load fail !!");
		} catch (SQLException e) {
			System.out.println("DB SQLException fail !!");
			e.printStackTrace();
		}
		finally
		{
			
			if (pstmt != null) {
				try{
					pstmt.close(); 
				} 
				catch(SQLException ex) {
					System.out.println("DB pstmt close exception !!");	
				}
			}
			if (con != null) {
				try {
					con.close(); 
				}
				catch(SQLException ex) {
					System.out.println("DB connection close exception !!");	
				}
			}
		}
	}
}
