package com.db.ex1_driver;

import java.sql.*;

public class JdbcDriver {

	public static void main(String[] args) {
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver"); 
			System.out.println("JDBC driver load success");
		} catch (ClassNotFoundException e) {
			System.out.println("JDBC driver load fail");
		}

	}
	
}
