package com.db.ex4_select;

import java.sql.*;
import java.util.*;
public class JdbcSelectColumn {
	
	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet=null;

		String driverName = "com.mysql.jdbc.Driver";
		String DBName = "jdbc_db";
		String dbURL = "jdbc:mysql://localhost:3306/" + DBName;
		String sslStr="?useSSL=false";

		String sql = "select date_time, date, time from mem_time";
	

		try {
			Class.forName(driverName);
			con = DriverManager.getConnection(dbURL+sslStr, "root", "1111133333");
			pstmt = con.prepareStatement(sql);
			resultSet = pstmt.executeQuery();

			while (resultSet.next()) 
			{
				java.sql.Timestamp dbSqlTimestamp = resultSet.getTimestamp(1);
				java.sql.Date dbSqlDate = resultSet.getDate(2);
				java.sql.Time dbSqlTime = resultSet.getTime(3);
		        
				System.out.println("--- sql date ----");
		        System.out.println("dbSqlTime=" + dbSqlTime);
		        System.out.println("dbSqlDate=" + dbSqlDate);
		        System.out.println("dbSqlTimestamp=" + dbSqlTimestamp);

		        
		        java.util.Date dbSqlTimeConverted = new java.util.Date(dbSqlTime.getTime());
		        java.util.Date dbSqlDateConverted = new java.util.Date(dbSqlDate.getTime());
		        System.out.println("--- util date ----");
		        System.out.println(dbSqlTimeConverted);
		        System.out.println(dbSqlDateConverted);
		        
		        Calendar cal = Calendar.getInstance();	      
		        cal.setTime(dbSqlDateConverted);
		        System.out.println("--- Calendar ----");
	        
		        System.out.println("month : " + (cal.get(Calendar.MONTH) + 1));
		        System.out.println("hour : " +  cal.get(Calendar.HOUR_OF_DAY));

		        

		        
		        
			}

		}
		catch (ClassNotFoundException e) {
				System.out.println("JDBC driver load fail !!");
		} catch (SQLException e) {
			System.out.println("DB SQLException fail !!");
			e.printStackTrace();
		
		}
		finally
		{
			if (resultSet != null) {
				try{
					resultSet.close(); 
				} 
				catch(SQLException ex) {
					System.out.println("DB resultSet close exception !!");	
				}
			}
			if (pstmt != null) {
				try{
					pstmt.close(); 
				} 
				catch(SQLException ex) {
					System.out.println("DB pstmt close exception !!");	
				}
			}
			if (con != null) {
				try {
					con.close(); 
				}
				catch(SQLException ex) {
					System.out.println("DB connection close exception !!");	
				}
			}
		}
	}
}
