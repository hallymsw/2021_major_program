package com.db.ex8_time_function;

import java.sql.*;

public class JdbcSelectDateTime {
	
	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet=null;

		String driverName = "com.mysql.jdbc.Driver";
		String DBName = "jdbc_db";
		String dbURL = "jdbc:mysql://localhost:3306/" + DBName;
		String sslStr="?useSSL=false";

		String sql = "SELECT  id, addr FROM user";
	
		try {
			Class.forName(driverName);
			con = DriverManager.getConnection(dbURL+sslStr, "root", "1111133333");
			pstmt = con.prepareStatement(sql);
			resultSet = pstmt.executeQuery();

			while (resultSet.next()) 
			{
				System.out.print(resultSet.getString("id")+"\t");
				System.out.println(resultSet.getString("addr")+"\t");
			}
		}
		catch (ClassNotFoundException e) {
				System.out.println("JDBC driver load fail !!");
		} catch (SQLException e) {
			System.out.println("DB SQLException fail !!");
		}
		finally
		{
			if (resultSet != null) {
				try{
					resultSet.close(); 
				} 
				catch(SQLException ex) {
					System.out.println("DB resultSet close exception !!");	
				}
			}
			if (pstmt != null) {
				try{
					pstmt.close(); 
				} 
				catch(SQLException ex) {
					System.out.println("DB pstmt close exception !!");	
				}
			}
			if (con != null) {
				try {
					con.close(); 
				}
				catch(SQLException ex) {
					System.out.println("DB connection close exception !!");	
				}
			}
		}
	}
}
