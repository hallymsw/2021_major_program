package com.sw.ui;
import java.util.*;
import com.sw.process.*;
public interface Ui {
	public static final int SearchByName=1;
	public static final int SearchByNumber=2;
	public static final int SearchByDept=3;
	public static final int Exit=4;
	
	public void showMenu();
	public void showSearchWordStep(); 
	public int getUserSelection();
	public String getKeyWord();
	public void printSearchByName(List<StudentInfo> pList);
		
	public void printNoData();
	public void printSearchByNumber(StudentInfo si);
	public void printSearchByDept(List<StudentInfo> pList);
	
}
