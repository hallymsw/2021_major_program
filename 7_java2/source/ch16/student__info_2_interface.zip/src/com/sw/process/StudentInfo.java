package com.sw.process;

public class StudentInfo {
	public String name;
	public String num;
	public String tel;
	public String dept;
}
