package com.sw.process;

import java.util.*;


public interface DataAccess {
	
//	public List<StudentInfo> getStudnetList();
	public int addData(StudentInfo si);
	public List<StudentInfo> getDataByName(String name);
	public StudentInfo getDataByNum(String num);
	public List<StudentInfo> getDataByDept(String dept);
	public void printStudentInfo();
}
