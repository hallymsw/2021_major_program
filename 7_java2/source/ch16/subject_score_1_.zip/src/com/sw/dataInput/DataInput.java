package com.sw.dataInput;

import java.io.*;



public interface DataInput {
	
	static final int FileSuccess_RET=1;
	static final int FileNotFoundException_RET=-1;
	static final int IOEXCEPTION_RET=-2;
	static final int CLOSE_IOEXCEPTION_RET=-3;
	
	
	public int dataInput(String fileName);

	
}
