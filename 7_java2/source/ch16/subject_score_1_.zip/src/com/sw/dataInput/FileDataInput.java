package com.sw.dataInput;

import java.io.*;
import java.util.*;

import com.sw.data.*;


public class FileDataInput implements DataInput {

	public DataAccess da = null;

	public FileDataInput(DataAccess da){
		this.da = da;
		
	}
	public void setDataAccessObj (DataAccess pda) {
		
	}
	public int dataInput(String fileName) {
		int ret=FileSuccess_RET;
		FileReader filereader= null;
		File file = null;
		int rowCount=1;
		BufferedReader bufReader = null;
        try{
            //파일 객체 생성
            file = new File(fileName);
            //입력 스트림 생성
            filereader = new FileReader(file);
            //입력 버퍼 생성
            bufReader = new BufferedReader(filereader);
            String line = "";
            while((line = bufReader.readLine()) != null){
            	            	
//            	System.out.println(line);
            	if(rowCount!=1) {
            		saveDataFromRowString(line);
            	}
                
                rowCount++;
            	
                
            } 
            DataAccessImpl dai =(DataAccessImpl)da;
            dai.printStudentInfo();
        }catch (FileNotFoundException e) {
        	System.out.println(e);
        	return FileNotFoundException_RET;
        }catch(IOException e){
            System.out.println(e);
            return IOEXCEPTION_RET;
        }
        finally{
        	try{
        		bufReader .close();
			}catch(IOException e){
				System.out.println(e);
	        	return CLOSE_IOEXCEPTION_RET;   
			}
		}
		return ret;
	}
	public int saveDataFromRowString(String rowStr) {
		int ret=0;
		int score=0;
		String[] data=rowStr.split(" ");
		int scoreLen=data.length-1;

//		printStringArr(data);
		List<Integer> scoreList = new ArrayList<Integer>();
		for(int i=1;i<scoreLen;i++) {
			score=Integer.parseInt(data[i]);
			scoreList.add(score);
		}
	
		StudentScore sco = new StudentScore(scoreList);
		sco.name=data[0];
		da.addData(sco);
		return ret;
	}
	void printStringArr(String[] strArr) {
		System.out.println("-- printStringArr() --");
		for(int i=0;i<strArr.length;i++) {
			System.out.println(strArr[i]);
		}
		System.out.println("------------------------");
	}
}
