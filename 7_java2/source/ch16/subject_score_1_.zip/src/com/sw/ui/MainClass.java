package com.sw.ui;

import com.sw.data.*;
import com.sw.dataInput.DataInput;
import com.sw.dataInput.FileDataInput;

public class MainClass {

	public static void main(String[] args) {
		String fileName="subject_score.txt";
		DataAccess da = new DataAccessImpl();
		DataInput fi = new FileDataInput(da);
		fi.dataInput(fileName);
		

	}

}
