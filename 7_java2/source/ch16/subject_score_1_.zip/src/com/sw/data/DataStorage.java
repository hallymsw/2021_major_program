package com.sw.data;

import java.util.*;

public class DataStorage {
	private List<StudentScore> stList = null;
	private List<Double> stAvgList = null;
	private List<Double> subAvgList = null;
	private List<String> rankList = null;
	public DataStorage() {
		stList= new ArrayList<StudentScore>();
		stAvgList = new ArrayList<Double>();
		subAvgList = new ArrayList<Double>();
		rankList = new ArrayList<String>();
	}
	public  List<StudentScore> getStudentList(){
		return stList;
	}
	
}
