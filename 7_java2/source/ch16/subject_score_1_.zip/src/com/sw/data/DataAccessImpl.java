package com.sw.data;

import java.util.*;




public class DataAccessImpl implements DataAccess{
	DataStorage ds=null;
	public DataAccessImpl() {
		ds=new DataStorage();
	}
	public int addData(StudentScore si) {
		int ret=0;
		List<StudentScore> stList = ds.getStudentList();
		stList.add(si);
		return ret;
	}
	public List<StudentScore> getDaStudentList(){
		List<StudentScore> retList = null;
		retList=ds.getStudentList();
		return retList;
	}
	public void addStAvg(double stAvg) {
		
	}
	public void addSubAvg(double subAvg) {
		
	}
	public void addRanker(String name) {
		
	}

	public List<Double> getStAvgList(){
		List<Double> ret=null;
		return ret;
	}
	public List<Double> getSubAvgList(){
		List<Double> ret=null;
		return ret;
	}
	public List<String> rankerList(){
		List<String> ret=null;
		return ret;
	}

	public void printStudentInfo() {
		System.out.println("-- printStudentInfo() --");
		List<StudentScore> stl=ds.getStudentList();
		for(int i=0;i<stl.size();i++) {
			StudentScore si =stl.get(i);
			System.out.println(si.name);
			for(int j=0;j<si.scoreList.size();j++) {
				System.out.print(si.scoreList.get(j)+" , ");
			}
		}
		System.out.println("------------------------");
		
		
	}
	
}
