package com.sw.data;

import java.util.*;


public interface DataAccess {
	
//	public List<StudentInfo> getStudnetList();
	public int addData(StudentScore si);
	public List<StudentScore> getDaStudentList();
	public void addStAvg(double stAvg);
	public void addSubAvg(double subAvg);
	public void addRanker(String name);
	public List<Double> getStAvgList();
	public List<Double> getSubAvgList();
	public List<String> rankerList();

}
