package com.sw.data;

import java.util.*;


public class StudentScore {
	public String name;
	public List<Integer> scoreList= null;
	public StudentScore(List<Integer> sl) {
		scoreList=sl;
	}
	
}
