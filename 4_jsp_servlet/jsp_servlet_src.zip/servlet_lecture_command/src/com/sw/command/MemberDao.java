package com.sw.command;
import java.sql.*;


public interface MemberDao {
	
	public int insertMember(MemberDto mdto);
	public String loginMember(String id);
	public Connection getConnection() ;
	public void closeConnection(ResultSet set, PreparedStatement pstmt, Connection connection);

}
