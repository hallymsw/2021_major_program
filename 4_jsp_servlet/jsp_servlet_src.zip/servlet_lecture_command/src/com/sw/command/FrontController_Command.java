package com.sw.command;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



/**
 * Servlet implementation class FrontController_Command
 */
@WebServlet("*.do")
public class FrontController_Command extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FrontController_Command() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		actionDo(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		actionDo(request, response);
	}
	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("actionDo");
		request.setCharacterEncoding("utf-8");

		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		System.out.println("uri - "+uri);
		System.out.println("conPath - "+conPath);
		System.out.println("com - "+com);

		MemberDto mdto = new MemberDto();
		Service command = null;
		String id = null;
		String pw = null;
		String name = null;
		int result=0;
		String result_page=null;
		HttpSession session = request.getSession();
		if(com.equals("/insert.do")) {
			id = request.getParameter("id");
			pw = request.getParameter("pw");
			name=request.getParameter("name");
			mdto.setId(id);
			mdto.setPw(pw);
			mdto.setName(name);
			command=new InsertCommandImpl();
			result=command.execute(mdto);
			result_page="insertResult.jsp";
			if(result==1)
			{
				session.setAttribute("insertResult", "join success");
			}
			else {
				session.setAttribute("insertResult", "join fail");
			}
		} else if(com.equals("/login.do")) {
			id = request.getParameter("id");
			pw = request.getParameter("pw");
			mdto.setId(id);
			mdto.setPw(pw);
			command=new LoginCommandImpl();
			result=command.execute(mdto);
			System.out.println("com - "+com);

			result_page="loginResult.jsp";
			if(result==1)
			{
				session.setAttribute("loginResult", "login success");
			}
			else {
				session.setAttribute("loginResult", "login fail");
			}
		} else {
			System.out.println("controller error");
		}
		response.sendRedirect(result_page);
	} 

}
