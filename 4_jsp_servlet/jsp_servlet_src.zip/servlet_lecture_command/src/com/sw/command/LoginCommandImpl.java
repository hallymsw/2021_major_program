package com.sw.command;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




public class LoginCommandImpl implements Service {

	@Override
	public int execute(MemberDto mdto) throws ServletException, IOException{
		
		String userId=mdto.getId();
		String userPw=mdto.getPw();
//		MemberDao mdao = new MemberDaoImpl();
		MemberDao mdao = new MemberFakeDaoImpl();
		String dbPw=mdao.loginMember(userId);
		System.out.println(dbPw+" , "+userPw);
		if(userPw.equals(dbPw)){
			return 1;
		}
		else {
			return -1;
		}		
	}
}
