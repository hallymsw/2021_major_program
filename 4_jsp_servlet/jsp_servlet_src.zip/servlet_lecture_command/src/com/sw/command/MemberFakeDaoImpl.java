package com.sw.command;

import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;




public class MemberFakeDaoImpl implements MemberDao{
	static ArrayList<MemberDto> dbData;
	public MemberFakeDaoImpl() {
		if(dbData==null) {
			dbData = new ArrayList<MemberDto>();
		}
		
	}
	public int insertMember(MemberDto mdto)
	{
		int ret=1;
		dbData.add(mdto);
		return ret;
	}
	
	public String loginMember(String id)
	{
		String pw=null;
		Iterator iterator = dbData.iterator();

		while(iterator.hasNext()){

			MemberDto data = (MemberDto)iterator.next();
			if(data.getId().equals(id)) {
				System.out.println(data.getId()+" , "+id);
				pw=data.getPw();
				System.out.println(data.getId()+" , "+id+" , "+pw);
			}

		}
		return pw;
	}

	public Connection getConnection() {
		
		Connection conn=null;		
		return conn;
	}
	public void closeConnection(ResultSet set, PreparedStatement pstmt, Connection connection) {
		
	}

}
