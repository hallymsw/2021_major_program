package com.sw.command;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public interface Service {
	public int execute(MemberDto mdto) throws ServletException, IOException;
}
