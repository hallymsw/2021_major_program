package com.sw.servlet_pr_book;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




public class QuizCommandImpl implements Service {

	@Override
	public int execute(QuizDto dto) throws ServletException, IOException{
		
		String id=dto.getId();
		String answer=dto.getAnswer();
//		QuizDao dao = new QuizDaoImpl();
		QuizDao dao = new QuizFakeDaoImpl();
		String dbAnswer=dao.quiz(id);
		if(answer.equals(dbAnswer)){
			return 1;
		}
		else {
			return -1;
		}		
	}
}
