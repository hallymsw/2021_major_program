package com.sw.servlet_pr_book;

import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;

public class QuizFakeDaoImpl implements QuizDao{
	static ArrayList<QuizDto> dbData;
	public QuizFakeDaoImpl() {
		if(dbData==null) {
			dbData = new ArrayList<QuizDto>();
		}
	}
	public int insert(QuizDto dto){
		dbData.add(dto);
		return 1;
	}
	
	public String quiz(String id){
		String answer=null;
		Iterator iterator = dbData.iterator();

		while(iterator.hasNext()){

			QuizDto data = (QuizDto)iterator.next();
			if(data.getId().equals(id)) {
				answer=data.getAnswer();
			}

		}
		return answer;
	}

	public Connection getConnection() {
		
		Connection conn=null;		
		
		return conn;
	}
	public void closeConnection(ResultSet set, PreparedStatement pstmt, Connection connection) {
		
	}

}
